package com.styleyar.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.graphics.Bitmap;
import android.database.Cursor;
import java.io.InputStream;
import android.util.Base64;
import java.io.ByteArrayOutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int PICK_IMAGE = 1001;
    private static final int TAKE_PHOTO = 1002;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(250,248,244));
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(250,248,244));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class Bridge {
        @JavascriptInterface public void pickImage() {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            startActivityForResult(i, PICK_IMAGE);
        }
        @JavascriptInterface public void takePhoto() {
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (i.resolveActivity(getPackageManager()) != null) startActivityForResult(i, TAKE_PHOTO);
        }
        @JavascriptInterface public void openUrl(String url) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(Exception ignored) {}
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == PICK_IMAGE && data.getData() != null) {
            try {
                InputStream in = getContentResolver().openInputStream(data.getData());
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf,0,n);
                in.close();
                String base64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                webView.evaluateJavascript("window.onNativeImageSelected && window.onNativeImageSelected('data:image/jpeg;base64," + base64 + "')", null);
            } catch(Exception ignored) {}

        } else if (requestCode == TAKE_PHOTO && data.getExtras() != null) {
            Bitmap b = (Bitmap) data.getExtras().get("data");
            if (b != null) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                b.compress(Bitmap.CompressFormat.JPEG, 85, out);
                String base64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                webView.evaluateJavascript("window.onNativePhotoTaken && window.onNativePhotoTaken('data:image/jpeg;base64," + base64 + "')", null);
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
